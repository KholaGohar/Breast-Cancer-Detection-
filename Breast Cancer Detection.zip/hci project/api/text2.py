import torch
import torch.nn as nn
from fastapi import FastAPI, UploadFile, File
from torchvision import transforms
from PIL import Image
import io
import os


def remove_prefix(state_dict, prefix):
    """Old style model is stored with all names of parameters starting with `prefix`"""
    keys = sorted(state_dict.keys())
    for key in keys:
        if key.startswith(prefix):
            newkey = key[len(prefix):]
            state_dict[newkey] = state_dict.pop(key)
    return state_dict

# Define the CNN model class (same as your trained model)
class CNN(nn.Module):
    def __init__(self, width:int=227, height:int=227):
        super().__init__()
        def layer(input_channel: int, 
                  output_channel: int, 
                  kernel_size_conv: int=3, 
                  padding: str='same', 
                  stride_conv: int=1, 
                  kernel_size_maxpool: int=2, 
                  stride_maxpool: int=2,
                  normalize=True,
                  maxpool=True):
            layers = [nn.Conv2d(input_channel, 
                                output_channel, 
                                kernel_size_conv,
                                stride_conv,
                                padding)]
            if normalize:
                layers.append(nn.BatchNorm2d(output_channel))
            layers.append(nn.ReLU())
            if maxpool:
                layers.append(nn.MaxPool2d(kernel_size=kernel_size_maxpool, 
                                           stride=stride_maxpool))
            return layers
        
        self.model = nn.Sequential(
                        *layer(input_channel=1,
                               output_channel=8),
                        *layer(input_channel=8,
                               output_channel=16),
                        *layer(input_channel=16,
                               output_channel=32,
                               maxpool=False)
                    )
        
        self.relu = nn.ReLU()
        self.fc1 = nn.Linear((width//4) * (height//4) * 32, 512)
        self.fc2 = nn.Linear(512, 128)
        self.fc3 = nn.Linear(128, 2)
        self.softmax = nn.Softmax(dim=1)
    def forward(self, x):
        x = self.model(x.float())
        x = torch.flatten(x, 1)
        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.fc3(x)
        x = self.softmax(x)
        return x

# Initialize the FastAPI app
app = FastAPI()

# Load the trained model
model_path = os.path.abspath("./model4/model_ver3.ckpt")
print(f"Model path: {model_path}")

model = CNN(width=227, height=227)
checkpoint = torch.load(model_path, map_location=torch.device('cpu'))
state_dict = checkpoint['state_dict']
state_dict = remove_prefix(state_dict, 'model.')

model.load_state_dict(state_dict)
model.eval()

# Define the image transformations
transform = transforms.Compose([
    transforms.Resize((227, 227)),
    transforms.ToTensor()
])

# Define the prediction endpoint
@app.post("/predict/")
async def predict(file: UploadFile = File(...)):
    # Read the image file
    image_bytes = await file.read()
    image = Image.open(io.BytesIO(image_bytes)).convert("L")
    
    # Apply the transformations
    image = transform(image).unsqueeze(0)  # Add batch dimension
    
    # Log the input shape
    print(f"Input image shape: {image.shape}")
    
    # Make prediction
    with torch.no_grad():
        outputs = model(image)
        print(f"Model outputs: {outputs}")  # Log model outputs
        _, predicted = torch.max(outputs, 1)
        label = predicted.item()
        print(f"Predicted label: {label}")  # Log the predicted label
    
    return {"label": label}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)
